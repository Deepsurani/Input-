from django.shortcuts import render, redirect

# Create your views here.
def HomePage(request):
   return render(request,"User/index.html")

# HomePage Post Call
def btn1Click(request):
    if(request.method == 'POST'):
        t1 = request.POST['txt1']
        ReturnMessage = {
            'msg':t1
        }
        return render(request,"User/index.html",ReturnMessage)

# Page2
def Page2(request):
    return render(request,"User/Page2.html")

def btn1Page2(request):
    if(request.method == "POST"):
        t1 = request.POST['txt1']
        t2 = request.POST['txt2']
        t3 = request.POST['txt3']
        Concat = t1 +" "+ t2+" "+ t3
        Message = {
            'join':Concat
        }
        return render(request,"User/Page2.html",Message)
    return redirect(Page2)