
from django.urls import path
from .import views

urlpatterns = [
    path('', views.HomePage,name="Home"),
    path('btn1Click',views.btn1Click,name="Btn1Click"),
    path('page2',views.Page2, name="Page2"),
    path('btn1Page2',views.btn1Page2, name="btn1Page2"),
]
